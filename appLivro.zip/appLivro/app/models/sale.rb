class Sale < ActiveRecord::Base
  belongs_to :livro
end
